/*
 * cli.c
 *
 *  Created on: Nov 26, 2017
 *      Author: sid
 */
#include <stdio.h>
#include <string.h>
#include "platform.h"
#include "xil_printf.h"
#include "sleep.h"
#include "cli.h"

#define CMD_SIZE      (100)
#define CMD_HIST_SIZE (10)

static char cmd_history_table[CMD_HIST_SIZE][CMD_SIZE];
static uint32_t cmd_history_table_current_index = CMD_HIST_SIZE - 1;

// ----------------------------------------------------------------------------
// Make changes to the command table.
// ----------------------------------------------------------------------------

// These callbacks and command table goes in its own file
// so this file is not updated when new commands are added.
// This file is not to be touched once complete.
static void menu_cmd_cb(int argc, char *argv[]);
static void help_cmd_cb(int argc, char *argv[]);
static void history_cmd_cb(int argc, char *argv[]);

struct cli_cmds_t cmd_table[] =
{
    {
        "menu",
        "Command menu.",
        NULL,
        menu_cmd_cb
    },
    {
        "help",
        "Command help.",
        NULL,
        help_cmd_cb
    },
    {
        "history",
        "Command history.",
        NULL,
        history_cmd_cb
    },
    {NULL, NULL, NULL, NULL}
};
static void print_args(int argc, char *argv[])
{
    xil_printf("argc = %d ", argc);
    for (uint32_t i = 0; i < argc; i++)
    {
        xil_printf("%s ", argv[i]);
    }
    xil_printf("\r\n");
}
static void history_cmd_cb(int argc, char *argv[])
{
    for (uint32_t i = 0; i < CMD_HIST_SIZE; i++)
    {
    	char *hs = cmd_history_table[i];
    	if (hs && (strlen(hs) > 0))
    	{
    		xil_printf("%s\r\n", hs);
    	}
    }
}
static void menu_cmd_cb(int argc, char *argv[])
{
	xil_printf(" ----------------------------------\r\n");
	xil_printf(" -------------- Menu --------------\r\n");
	xil_printf(" ----------------------------------\r\n");
	for (uint32_t i = 0; cmd_table[i].cb; i++)
	{
		char *cmd  = cmd_table[i].cmd;
		char *cmdd = cmd_table[i].cmd_description;
		char *cmda = cmd_table[i].cmd_arguments;
		if (cmd)
		{
            //xil_printf("   %d. %s %s\r\n\t\t%s \r\n", i, cmd, cmda ? cmda : " ", cmdd ? cmdd : " ");
            xil_printf("   %d. %s %s\r\n", i, cmd, cmda ? cmda : " ");
		}
	}
	xil_printf(" ----------------------------------\r\n\r\n");

}
static void help_cmd_cb(int argc, char *argv[])
{
    //xil_printf("\r\nhelp_cmd_cb\r\n");
    //print_args(argc, argv);
}
// ----------------------------------------------------------------------------




// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// Below this - DO NOT CHANGE.
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------



void cli_init(void)
{
    // Initialize the command history table.
    for (uint32_t i = 0; i < CMD_HIST_SIZE; i++)
    {
        for (uint32_t j = 0; j < CMD_SIZE; j++)
        {
            cmd_history_table[i][j] = '0';
        }
    }
}

static void cli_parse_cmd(char *cmd)
{
    static char *argv[NUM_ARGVS];
    int argc = 0;
    char *tok;
    char *tok_str = cmd;

    // Tokenize.
    while ((tok = strtok(tok_str, " ")) != NULL)
    {
        argv[argc] = tok;
        //xil_printf("cli_parse_cmd : %s\r\n", tok);
        argc++;
        tok_str = NULL;
    }

    // Based on argv[0] call the command and pass in arguments.
    for (uint32_t i = 0; cmd_table[i].cmd; i++)
    {
        if (!strcmp(cmd_table[i].cmd, argv[0]))
        {
            cmd_table[i].cb(argc, argv);
            goto cli_parse_cmd_exit;
        }
    }
cli_parse_cmd_exit:
   return;
}

void cli_task_blocking(void)
{
    static char cmd[CMD_SIZE];
    static uint32_t index = 0;
    char c;

    c = (char8)inbyte();
    if (c == '\r')
    {
        xil_printf("\r\n");
        cmd[index] = '\0';
        index = 0;

        if (strlen(cmd) > 0)
        {
            // Add cmd to the command list. First shift all commands
            // up the table by 1. Then copy new command into table.
            for (uint32_t i = 0; i < CMD_HIST_SIZE - 1; i++)
            {
        	    strncpy(cmd_history_table[i], cmd_history_table[i + 1], CMD_SIZE);
            }
            strncpy(cmd_history_table[CMD_HIST_SIZE - 1], cmd, CMD_SIZE);
            cmd_history_table_current_index = CMD_HIST_SIZE - 1;
        }

        cli_parse_cmd(cmd);
        xil_printf("> ");

        goto cli_task_exit;
    }
    else if (c == '\b')
    {
        xil_printf("\b ");
        cmd[index] = (char8)' ';
        if (index > 0)
            index--;
    }
    else if (c == 27)
    {
        c = (char8)inbyte(); // Get the [ character.
        c = (char8)inbyte(); // Get up, down, left, right.
        if (c == 'A') // up
        {
        	xil_printf("\033[1K");
        	for (uint32_t i = 0; i < CMD_SIZE; i++)
        	{
        		xil_printf("\b");
        	}

        	xil_printf("> ");
            xil_printf("%s", cmd_history_table[cmd_history_table_current_index]);
            strncpy(cmd, cmd_history_table[cmd_history_table_current_index], CMD_SIZE);
            index = strlen(cmd);

            // Move to the past in history.
            if ((cmd_history_table_current_index > 0) &&
                (strlen(cmd_history_table[cmd_history_table_current_index - 1]) > 0)
            )
            {
            	cmd_history_table_current_index--;
            }
        }
        else if (c == 'B') // down
        {
        	xil_printf("\033[1K");
        	for (uint32_t i = 0; i < CMD_SIZE; i++)
        	{
        		xil_printf("\b");
        	}
        	xil_printf("> ");
            xil_printf("%s", cmd_history_table[cmd_history_table_current_index]);
            strncpy(cmd, cmd_history_table[cmd_history_table_current_index], CMD_SIZE);
            index = strlen(cmd);

            // Move to the past in history.
            if ((cmd_history_table_current_index < CMD_HIST_SIZE - 1) &&
                (strlen(cmd_history_table[cmd_history_table_current_index]) > 0))
            {
            	cmd_history_table_current_index++;
            }
        }
        else if (c == 'C') // Forward.
        {
            xil_printf("forward ");
        }
        else if (c == 'D') // backward
        {
            xil_printf("backward ");
        }

        // Simulates a continue so the last \r is not printed again.
        goto cli_task_exit;
    }
    else
    {
        cmd[index] = c;
        if (index < 100)
            index++;
    }
    xil_printf("%c", c);

cli_task_exit:
    return;
}
